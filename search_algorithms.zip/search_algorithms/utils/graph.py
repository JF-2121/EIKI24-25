class Edge():
    def __init__(self, a, b, cost=None):
        self.a = a
        self.b = b
        self.cost = cost


class Node:
    def __init__(self, value, name=None, h=None):
        self.value = value
        if name is None:
            self.name = value
        # Mapping from Node to cost, derived from edge connecting them
        self.cost_to = {}

        # for A* Search
        self.f = float("inf")
        self.g = 0
        self.h = h
        self.previous_node = None

    def neighbors(self):
        return list(self.cost_to.keys())

    # alias for neighbors for tree search
    def children(self):
        return self.neighbors()


class Graph:
    def __init__(self, nodes, edges, heuristic=None):
        self.nodes = []
        self.edges = []
        for node in nodes:
            if type(node) is str:
                self.nodes.append(Node(node))
            else:
                self.nodes.append(node)

        for edge in edges:
            if type(edge) is Edge:
                self.edges.append(edge)
            else:
                self.edges.append(Edge(*edge))





        self.node_mapping = {node.name: node for node in self.nodes}

        # Assert each node has unique name.
        name_list = self.node_mapping.keys()
        unique_names = set(name_list)
        assert len(name_list) == len(unique_names), \
            "Two nodes cannot have the same name. Check the nodes you pass to the Graph."

        for edge in self.edges:
            assert edge.a in self.node_mapping, f"Node {edge.a.name} from edge {edge} doesn't exist"
            assert edge.b in self.node_mapping, f"Node {edge.b.name} from edge {edge} doesn't exist"
            self.connect_nodes(edge)

        if heuristic is not None:
            for node in self.nodes:
                assert node.name in heuristic or node.h is not None, f"Node {node.name} needs a heuristic value if a heuristic is given to the graph"
                if node.name in heuristic:
                    node.h = heuristic[node.name]

    def connect_nodes(self, edge):
        pass


class DirectedGraph(Graph):
    def __init__(self, nodes, edges, heuristic=None):
        super(DirectedGraph, self).__init__(nodes, edges, heuristic=heuristic)

    def connect_nodes(self, edge):
        node_a = self.node_mapping[edge.a]
        node_b = self.node_mapping[edge.b]

        node_a.cost_to[node_b] = edge.cost


class UndirectedGraph(Graph):
    def __init__(self, nodes, edges, heuristic=None):
        super(UndirectedGraph, self).__init__(nodes, edges, heuristic=heuristic)

    def connect_nodes(self, edge):
        node_a = self.node_mapping[edge.a]
        node_b = self.node_mapping[edge.b]

        node_a.cost_to[node_b] = edge.cost
        node_b.cost_to[node_a] = edge.cost
