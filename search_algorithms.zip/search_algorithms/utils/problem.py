from .log import  SearchBacklog
from .graph import Node, DirectedGraph, UndirectedGraph


class SearchProblem:
    def __init__(self, start_node=None, target_node=None, graph=None):
        if start_node is not Node:
            start_node = graph.node_mapping[start_node]

        if target_node is not Node:
            target_node = graph.node_mapping[target_node]

        if type(graph) is DirectedGraph:
            backlog = SearchBacklog(self, directed=True)
        elif type(graph) is UndirectedGraph:
            backlog = SearchBacklog(self, directed=False)
        else:
            exit(1, "Graph is neither Directed nor Undirected.")

        self.graph = graph
        self.target_node = target_node
        # Alias these
        self.root = start_node
        self.start_node = start_node
        self.backlog = backlog
