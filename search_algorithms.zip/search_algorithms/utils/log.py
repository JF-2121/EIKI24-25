#from graphviz import Digraph, Graph

import matplotlib.pyplot as plt

import networkx as nx
import io
from .graph import Node

seed = 42
import random

random.seed(seed)  # or any integer
import numpy

numpy.random.seed(seed)


class TreeSearchLog():
    def __init__(self, node):
        self.node = node


class SearchLog():
    def __init__(self, entry, fringe=[], *args, **kwargs):
        if type(entry) is Node:
            self.node = entry
        else:
            for name, value in entry._asdict().items():
                setattr(self, name, value)

        self.fringe = [x for x in fringe]



class BacktrackLog():
    def __init__(self, csp, assignment, current):
        self.csp = csp
        self.assignment = assignment
        self.current = current

class ForwardCheckingLog():
    def __init__(self, csp, assignment, current):
        self.csp = csp
        self.assignment = assignment
        self.current = current   
        
class AC3Log():
    def __init__(self, csp, assignment, current, current_x, current_y):
        self.csp = csp
        self.assignment = assignment
        self.current = current
        self.current_x = current_x
        self.current_y = current_y
        

# ===============================================================================================================

class BaseBacklog():
    def __init__(self):
        self.logs = []

    def add_log(self, *args):
        """
        create correct log object and append it
        """
        pass

    def render(self):
        """
        expected to return a list of byte images
        """
        pass

# ===============================================================================================================
"""

class DirectedSearchBacklog(BaseBacklog):
    def __init__(self, search_problem):
        self.search_problem = search_problem
        self.logs = []

    def add_log(self, *args):
        create correct log object and append it
        self.logs.append(TreeSearchLog(*args))

    def to_dot_tree(self):
        dot = Digraph(graph_attr={'dpi': '400'})
        for node in self.search_problem.graph.nodes:
            dot.node(name=str(node.name))

        for edge in self.search_problem.graph.edges:
            label = str(edge.cost) if edge.cost == 0 else None
            dot.edge(str(edge.a), str(edge.b), label=label)


        return dot

    def change_color(self, log_num, dot=None):
        log = self.logs[log_num]
        dot.node(name=str(log.node.value), color='green' if log.node is self.search_problem.target_node else 'red')
        return dot

    def render(self):
        expected to return a list of byte images
        images = []
        dot = self.to_dot_tree()
        for i, log in enumerate(self.logs):
            dot = self.change_color(i, dot)
            image_file = io.BytesIO(dot.pipe(format='png'))

            # To image:
            # import matplotlib.image as mpimg
            # images.append(mpimg.imread(image_file))

            images.append(image_file.read())
        return images

# ===============================================================================================================
"""


class SearchBacklog(BaseBacklog):
    def __init__(self, search_problem, directed=False):
        self.search_problem = search_problem
        self.logs = []
        self.node_previous_node_mapping = {}
        self.directed = directed

    def add_log(self, *args, **kwargs):
        """
        create correct log object and append it
        """
        self.logs.append(SearchLog(*args, **kwargs))

    def draw_graph(self, log_num):

        if self.directed:
            G = nx.DiGraph()
        else:
            G = nx.Graph()

        log = self.logs[log_num]

        # Keep track of this since it changes
        if hasattr(log, "previous_node") and log.previous_node is not None:
            self.node_previous_node_mapping[log.node.name] = (log.node, log.previous_node)

        #####  Set labels  #####

        node_labels = {}
        edge_labels = {}

        # Adding edges automatically adds nodes to the graph!
        for edge in self.search_problem.graph.edges:
            G.add_edge(edge.a, edge.b)
            if edge.cost is not None:
                edge_labels[(edge.a, edge.b)] = edge.cost

        for node in self.search_problem.graph.nodes:
            node_label = str(node.name)

            if node.h is not None:
                node_label += f'\nh = {node.h}'
            node_labels[node.name] = node_label

        visited_nodes = []
        for i in range(log_num + 1):
            prev_log = self.logs[i]
            visited_nodes.append(prev_log.node.name)
            if prev_log.node.h is not None:
                node_label = str(prev_log.node.name)
                node_label += f'\nh = {prev_log.node.h}'
                node_label += f'\ng = {prev_log.g}' if hasattr(prev_log, 'g') else ''
                node_label += f'\nf = {prev_log.f}'

                node_labels[prev_log.node.name] = node_label

        ##### Changing colors #####

        node_colors = []
        edge_colors = []

        # Iterate over G.nodes after adding edges. We need to use the order provided from networkx so the colors are in
        # the same order in their lists.
        for node_name in G.nodes:
            if node_name in visited_nodes:
                node_colors.append('green' if node_name is self.search_problem.target_node.name else 'red')
            else:
                node_colors.append('gray')

        for node1, node2 in G.edges():
            if node1 in self.node_previous_node_mapping and self.node_previous_node_mapping[node1][1].name == node2:
                edge_colors.append('blue')
            elif node2 in self.node_previous_node_mapping and self.node_previous_node_mapping[node2][1].name == node1:
                edge_colors.append('blue')
            else:
                edge_colors.append('gray')

        # For directed graphs the planar-spring combination does not work. We have to create an undirected one to get
        # the correct positions to use with whatever graph we want.
        H = G.to_undirected()
        pos = nx.planar_layout(H)
        pos = nx.spring_layout(H, pos=pos)
        fig, ax = plt.subplots(figsize=(8, 8))

        if hasattr(log, 'fringe'):
            l = []
            for entry in log.fringe:
                #print(type(entry), type(entry) is Node)
                if type(entry) is Node:
                    l.append(entry.name)
                else:

                    if hasattr(entry, 'f'):
                        l.append(f'{entry.node.name}')


            ax.set_title(f'Fringe: {", ".join(l)}')


        # Draw everything we specified above
        nx.draw_networkx_nodes(G, pos, ax=ax, node_size=2400, node_color='lightgray', edgecolors=node_colors,
                               linewidths=2)
        nx.draw_networkx_labels(G, pos, ax=ax, font_size=8, labels=node_labels)

        nx.draw_networkx_edges(G, pos, ax=ax, edge_color=edge_colors, width=3, node_size=2400, arrows=True)
        nx.draw_networkx_edge_labels(G, pos, ax=ax, edge_labels=edge_labels)


        image_file = io.BytesIO()
        fig.savefig(image_file, format='png', dpi=200)
        plt.close()

        # Important line!
        image_file.seek(0)

        return image_file

    def render(self):
        """
        expected to return a list of byte images
        """
        # reset mapping
        self.node_previous_node_mapping = {}
        from PIL import Image
        images = []
        for i, log in enumerate(self.logs):
            image_file = self.draw_graph(i)

            images.append(image_file.read())
        return images


"""
# ===============================================================================================================

class UndirectedSearchBacklog(BaseBacklog):
    def __init__(self, search_problem):
        self.search_problem = search_problem
        self.logs = []
        self.node_previous_node_mapping = {}

    def add_log(self, *args):
        create correct log object and append it
        self.logs.append(GraphSearchLog(*args))

    def to_dot_tree(self):

        dot = Graph(graph_attr={'dpi': '800'}, strict=True)
        for node in self.search_problem.graph.nodes:
            node_label = str(node.name)
            if node.h is not None:
                node_label += f'\nh = {node.h}'
                node_label += f'\ng = {node.g}'
                node_label += f'\nf = {node.f}'
            dot.node(name=str(node.name), label=node_label)

        for edge in self.search_problem.graph.edges:
            label = str(edge.cost) if edge.cost is not None else None
            dot.edge(str(edge.a), str(edge.b), label=label, _attributes={'dir':'none'} )

        return dot

    def update_edge_colors(self, log_num, dot):
        log = self.logs[log_num]
        if hasattr(log, "previous_node"):
            pass


    def update_graph(self, log_num, dot=None):
        log = self.logs[log_num]

        if hasattr(log, "previous_node"):
            self.node_previous_node_mapping[log.node.name] = (log.node, log.previous_node)


            for edge in self.search_problem.graph.edges:
                label = str(edge.cost) if edge.cost is not None else None
                dot.edge(str(edge.a), str(edge.b), label=label,color='black', _attributes={'dir': 'none' })

            for node_name, (node, previous_node) in self.node_previous_node_mapping.items():
                if previous_node is not None:

                    print(node.name, previous_node.name)
                    dot.edge(str(previous_node.name), str(node.name), color='green', _attributes={'dir': 'none'})


        node_label = str(log.node.name)
        if log.node.h is not None:
            node_label += f'\nh = {log.node.h}'
            node_label += f'\ng = {log.g}'
            node_label += f'\nf = {log.f}'

        dot.node(name=str(log.node.name), label=node_label, color='green' if log.node is self.search_problem.target_node else 'red')

        return dot

    def render(self):
        expected to return a list of byte images
        # reset mapping
        self.node_previous_node_mapping = {}

        images = []
        dot = self.to_dot_tree()
        for i, log in enumerate(self.logs):
            dot = self.update_graph(i, dot)
            image_file = io.BytesIO(dot.pipe(format='png'))

            # To image:
            # import matplotlib.image as mpimg
            # images.append(mpimg.imread(image_file))

            images.append(image_file.read())
        return images

# ===============================================================================================================
"""

"""
class BacktrackBacklog(BaseBacklog):
    def __init__(self):
        self.logs = []

    def add_log(self, *args):
        self.logs.append(BacktrackLog(*args))
    
    def to_dot_graph(self, log_num, dot=None):
        log = self.logs[log_num]
        
        for key in log.csp["variables"]:
            if (key!=log.current):
                dot.node(name=key)
            else:
                dot.node(name=log.current, color='green' if log.assignment[log.current]==1 
                                               else 'blue' if log.assignment[log.current]==2 
                                                   else 'red')    
        if (log_num==0):
            for con in log.csp["constraints"].values():                     
                dot.edge(con["variable1"], con["variable2"])      
        return dot

    def render(self):
        images = []
        dot = Graph(graph_attr={'dpi': '400'})
        for i, log in enumerate(self.logs):
            dot = self.to_dot_graph(i, dot)
            image_file = io.BytesIO(dot.pipe(format='png'))
            images.append(image_file.read())
        return images
        
# ===============================================================================================================
"""

class BacktrackBacklog(BaseBacklog):
    def __init__(self):
        self.logs = []

    def add_log(self, *args):
        self.logs.append(BacktrackLog(*args)) 
        
    def draw_graph(self, log_num):

        G = nx.Graph()
        log = self.logs[log_num]
        color_map = []
        node_labels = {}
        plt.ioff()
        
        
        # Adding the nodes and assigning the colors
        for key in log.csp["variables"]:
            G.add_node(key)
            if key in log.assignment:
                if (log.assignment[key]==1):
                    color_map.append("LightGreen")
                elif (log.assignment[key]==2):
                    color_map.append("DeepSkyBlue")
                else:
                    color_map.append("Tomato")
            else:
                color_map.append("lightgray")
                
                
        # Adding edges and labels
        for node in G:
            node_labels[node] = str(node)
            
        for con in log.csp["constraints"].values():                     
            G.add_edge(con["variable1"], con["variable2"])  
            
        
        # using the kamada kawai layout to layout the graph
        pos = nx.kamada_kawai_layout(G)
        fig, ax = plt.subplots(figsize=(6, 6))
        
        
        # Draw everything we specified above
        nx.draw_networkx_nodes(G, pos, node_size=1000, node_color=color_map, edgecolors="grey", linewidths=2)
        
        nx.draw_networkx_labels(G, pos, font_size=8, labels=node_labels)

        nx.draw_networkx_edges(G, pos, width=3, edge_color="grey", node_size=1000, arrows=False) 

        
        # saving the image
        image_file = io.BytesIO()
        fig.savefig(image_file, format='png', dpi=200)
        plt.close()
        
        # Important line!
        image_file.seek(0)

        return image_file
    
    def render(self):
        from PIL import Image
        images = []
        for i, log in enumerate(self.logs):
            image_file = self.draw_graph(i)
            images.append(image_file.read())
        return images
"""
# ===============================================================================================================
    
class ForwardCheckingBacklog(BaseBacklog):
    def __init__(self):
        self.logs = []

    def add_log(self, *args):
        self.logs.append(ForwardCheckingLog(*args))
    
    def to_dot_graph(self, log_num, dot=None):
        log = self.logs[log_num]
        for key in log.csp["variables"]:
            if (key!=log.current):
                dot.node(name=key, xlabel=str(log.values[key]))
            else:
                dot.node(name=str(log.current), 
                             xlabel=str(log.values[key]),
                                 color='green' if log.assignment[log.current]==1 
                                     else 'blue' if log.assignment[log.current]==2 
                                         else 'red')
        if (log_num==0):
            for con in log.csp["constraints"].values():                     
                dot.edge(con["variable1"], con["variable2"])
        return dot

    def render(self):
        images = []
        dot = Graph(graph_attr={'dpi': '400'})
        for i, log in enumerate(self.logs):
            dot = self.to_dot_graph(i, dot)
            image_file = io.BytesIO(dot.pipe(format='png'))
            images.append(image_file.read())
        return images

# ===============================================================================================================
"""

class ForwardCheckingBacklog(BaseBacklog):
    def __init__(self):
        self.logs = []

    def add_log(self, *args):
        self.logs.append(ForwardCheckingLog(*args))
        
    def draw_graph(self, log_num):

        G = nx.Graph()
        log = self.logs[log_num]
        color_map = []
        node_labels = {}
        node_values = {}
        plt.ioff()
        
        
        # Adding the nodes and assigning the colors
        for key in log.csp["variables"]:
            G.add_node(key)
            if key in log.assignment:
                if (log.assignment[key]==1):
                    color_map.append("LightGreen")
                elif (log.assignment[key]==2):
                    color_map.append("DeepSkyBlue")
                else:
                    color_map.append("Tomato")
            else:
                color_map.append("lightgray")
                
                
        # Adding edges and labels
        for node in G:
            node_labels[node] = str(node)
            if (node in log.assignment):
                node_values[node] = str([log.assignment[node]])
            else:
                node_values[node] = str(log.csp["variables"][node])
            
        for con in log.csp["constraints"].values():                     
            G.add_edge(con["variable1"], con["variable2"])
        
        
        # using the kamada kawai layout to layout the graph
        pos = nx.kamada_kawai_layout(G)
        fig, ax = plt.subplots(figsize=(6, 6))
        
        pos_values = {}
        for node, coords in pos.items():
            pos_values[node] = (coords[0], coords[1] + 0.14)
        
        
        # Draw everything we specified above
        nx.draw(G, pos, node_size=1000, node_color=color_map, edgecolors="grey", linewidths=2, labels=node_labels)
        
        nx.draw_networkx_labels(G, pos=pos_values, font_size=8, labels=node_values)
        
        nx.draw_networkx_edges(G, pos, width=3, edge_color="grey", node_size=1000, arrows=False)

        
        # saving the image
        image_file = io.BytesIO()
        fig.savefig(image_file, format='png', dpi=200)
        plt.close()
        
        # Important line!
        image_file.seek(0)

        return image_file
    
    def render(self):
        from PIL import Image
        images = []
        for i, log in enumerate(self.logs):
            image_file = self.draw_graph(i)
            images.append(image_file.read())
        return images


"""
# ===============================================================================================================
class AC3Backlog(BaseBacklog):
    def __init__(self):
        self.logs = []

    def add_log(self, *args):
        self.logs.append(AC3Log(*args))

    def to_dot_graph(self, log_num, dot=None):
        log = self.logs[log_num]
        for key in log.csp["variables"]:
            if (key!=log.current):
                dot.node(name=key, xlabel=str(log.csp["variables"][key]))
            else:
                dot.node(name=str(log.current),
                             xlabel=str(log.csp["variables"][key]),
                                 color='green' if log.assignment[log.current]==1
                                     else 'blue' if log.assignment[log.current]==2
                                         else 'red')
        for con in log.csp["constraints"].values():
            if (log.current_x != "undefined"):
                if ((log.current_x == con["variable1"] and log.current_y == con["variable2"])
                    or (log.current_x == con["variable2"] and log.current_y == con["variable1"])):

                    dot.edge(con["variable1"], con["variable2"], color='red')
                else:
                    dot.edge(con["variable1"], con["variable2"], color='black')
            else:
                dot.edge(con["variable1"], con["variable2"], color='black')
        return dot

    def render(self):
        images = []
        dot = Graph(graph_attr={'dpi': '400'}, strict=True)
        for i, log in enumerate(self.logs):
            dot = self.to_dot_graph(i, dot)
            image_file = io.BytesIO(dot.pipe(format='png'))
            images.append(image_file.read())
        return images

# ===============================================================================================================
"""

class AC3Backlog(BaseBacklog):
    def __init__(self):
        self.logs = []

    def add_log(self, *args):
        self.logs.append(AC3Log(*args))
        
    def draw_graph(self, log_num):

        G = nx.Graph()
        log = self.logs[log_num]
        color_map = []
        edge_color_map = []
        node_labels = {}
        node_values = {}
        plt.ioff()
        
        #print("assingment-after:", log.assignment)
        # Adding the nodes and assigning the colors
        for key in log.csp["variables"]:
            G.add_node(key)
            if key in log.assignment:
                if (log.assignment[key]==1):
                    color_map.append("LightGreen")
                elif (log.assignment[key]==2):
                    color_map.append("DeepSkyBlue")
                else:
                    color_map.append("Tomato")
            else:
                color_map.append("lightgray")
                
        # Adding edges and labels
        for node in G:
            node_labels[node] = str(node)
            node_values[node] = str(log.csp["variables"][node])
            
        for con in log.csp["constraints"].values():                     
            G.add_edge(con["variable1"], con["variable2"])
            if (log.current_x != "undefined"):
                if ((log.current_x == con["variable1"] and log.current_y == con["variable2"])
                    or (log.current_x == con["variable2"] and log.current_y == con["variable1"])):
                    edge_color_map.append("Tomato")
                else:
                    edge_color_map.append("gray")
            else:
                edge_color_map.append("gray")
        
        
        # using the kamada kawai layout to layout the graph
        pos = nx.kamada_kawai_layout(G)
        fig, ax = plt.subplots(figsize=(6, 6))
        
        pos_values = {}
        for node, coords in pos.items():
            pos_values[node] = (coords[0], coords[1] + 0.14)
        
        # Draw everything we specified above
        nx.draw(G, pos, node_size=1000, node_color=color_map, edgecolors="grey", linewidths=2, labels=node_labels)
        
        nx.draw_networkx_labels(G, pos=pos_values, font_size=8, labels=node_values)
        
        nx.draw_networkx_edges(G, pos, width=3, edge_color=edge_color_map, node_size=1000, arrows=False)

        
        # saving the image
        image_file = io.BytesIO()
        fig.savefig(image_file, format='png', dpi=200)
        plt.close()
        
        # Important line!
        image_file.seek(0)

        return image_file
    
    def render(self):
        from PIL import Image
        images = []
        for i, log in enumerate(self.logs):
            image_file = self.draw_graph(i)
            images.append(image_file.read())
        return images
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
