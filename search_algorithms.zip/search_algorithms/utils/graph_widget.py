from IPython.display import display
import ipywidgets as widgets
from ipywidgets import interact
import matplotlib.pyplot as plt

# needed to link buttons and slider
from traitlets import CInt, link
class Counter(widgets.DOMWidget):
    value = CInt(0, sync=True)

def show(backlog):
    counter = Counter()
    min_val = 0
    # Expects bytes
    images = backlog.render()
    max_val = len(images)-1

    def view_image(step):
        return widgets.Image(value=images[step], format='png', width=800,
                             height=800)
    def button_plus(name):
        counter.value += 1 if counter.value < max_val else 0

    def button_minus(name):
        counter.value -= 1 if counter.value > min_val else 0

    wplus = widgets.Button(description='>')
    wminus = widgets.Button(description='<')
    slider = widgets.IntSlider(min=min_val, max=max_val, step=1)
    link((slider, 'value'), (counter, 'value'))
    wplus.on_click(button_plus)
    wminus.on_click(button_minus)

    interact(view_image, step=slider)
    display(widgets.VBox([widgets.HBox([wminus, wplus])]))

def show_slider(backlog):
    """
    just a slider and the image
    """
    images = backlog.render(return_byte=True)
    max_val = len(images)-1
    def view_image(step):
        return widgets.Image(value=images[step], format='png', width=400,
                             height=400)


    interact(view_image, step=widgets.IntSlider(min=0, max=max_val, step=1))

def show_deprecated(backlog):
    """
    Some object that has a render function that returns a list of images
    """
    images = backlog.render()

    position = 0
    n = len(images)
    # create figure without any axis or border
    #fig = plt.figure(num='Step: 1')
    #ax = plt.Axes(fig, [0., 0., 1., 1.])
    #ax.set_axis_off()
    #fig.add_axes(ax)
    fig, ax = plt.subplots()

    ax.get_xaxis().set_visible(False)
    ax.get_yaxis().set_visible(False)
    ax.spines['top'].set_visible(False)
    ax.spines['left'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['bottom'].set_visible(False)
    #fig.suptitle(f'Step: {step + 1}')
    def view_image(step):
        nonlocal position
        position = step

        # ax.imshow(img)
        img = images[step]
        ax.imshow(img)
        fig.suptitle(f'Step: {step + 1}')
        #fig.canvas.manager.set_window_title(f'Step: {step + 1}')
        # fig.canvas.toolbar_visible = False
        ax.figure.canvas.draw_idle()
        #plt.show()

        # display(SVG(f'.temp/{step}.svg'))

    def start_step(btn):
        view_image(0)

    def end_step(btn):
        view_image(n-1)

    def next_step(btn):
        nonlocal position
        view_image(min(position + 1, n - 1))

    def prev_step(btn):
        nonlocal position
        view_image(max(position - 1, 0))

    def select_step(value):
        view_image(value - 1)

    view_image(0)
    #interact(select_step, value=widgets.IntSlider(min=1, max=n, step=1, value=1))
    start = widgets.Button(description='start')
    start.on_click(start_step)
    backward = widgets.Button(description='backward')
    backward.on_click(prev_step)
    forward = widgets.Button(description='forward')
    forward.on_click(next_step)
    end = widgets.Button(description='end')
    end.on_click(end_step)

    combined = widgets.HBox([start, backward, forward, end])
    #combined = widgets.HBox([backward, forward])
    display(combined)
